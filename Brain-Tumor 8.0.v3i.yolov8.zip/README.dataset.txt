# Brain-Tumor 8.0 > 2023-07-07 12:37am
https://universe.roboflow.com/namdp2810-gmail-com/brain-tumor-8.0

Provided by a Roboflow user
License: CC BY 4.0

